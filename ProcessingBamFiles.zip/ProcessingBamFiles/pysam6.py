import pysam
over=0
samfile = pysam.AlignmentFile("sorted1.bam", "rb" )
for pileupcolumn in samfile.pileup("4",0 ,20000000):
	over=pileupcolumn.n
	if over>0:
		break
print (pileupcolumn.pos)

samfile.close()

