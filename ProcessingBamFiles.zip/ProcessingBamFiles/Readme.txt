1. Install pysam and samtools

2. Download the high coverage .bam file from the following link
ftp://ftp.1000genomes.ebi.ac.uk/vol1/ftp/technical/pilot2_high_cov_GRCh37_bams/data/

3. Use the following code in the terminal to create an indexed .bam named sorted.bam
samtools view -b -F 4
NA12878.chrom14.LS454.ssaha2.CEU.high_coverage.20100311.bam &gt;
mapped1.bam
samtools view -c mapped1.bam
samtools sort mapped1.bam sorted1
samtools index sorted1.bam

4. After step 3 , Run the python code provided in the following order to extract information:-

a) Pysam1.py
b) Pysam_mat.py
c) Pysam3.py
d) Pysam4.py
e) Pysam5.py
f) Pysam6.py
g) Pysam2.py
 
