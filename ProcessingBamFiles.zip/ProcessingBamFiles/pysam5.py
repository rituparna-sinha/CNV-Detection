import pysam
samfile = pysam.AlignmentFile("sorted1.bam", "rb" )
for pileupcolumn in samfile.pileup("20", 2072700000 , None):
	print ("\ncoverage at base %s = %s" %
				(pileupcolumn.pos, pileupcolumn.n))
samfile.close()
