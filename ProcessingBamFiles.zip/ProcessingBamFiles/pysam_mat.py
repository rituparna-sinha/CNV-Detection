import pysam
samfile = pysam.AlignmentFile("sorted1.bam", "rb" )
d={}
for pileupcolumn in samfile.pileup("20", 20000017 , 20000269):
    d.update({pileupcolumn.pos:pileupcolumn.n})

key=[]
value=[]
for k,v in d.items():
	key.append(k)
	value.append(v)
 

import matplotlib.pyplot as plt
plt.plot(key,value)
plt.show()
  
