import pysam
samfile = pysam.AlignmentFile("sorted1.bam", "rb" )
for read in samfile. fetch(contig=None, start=20000017, stop=None, region=None, tid=None, until_eof=False, multiple_iterators=False, reference=None, end=None):
	print (read)

samfile.close()
