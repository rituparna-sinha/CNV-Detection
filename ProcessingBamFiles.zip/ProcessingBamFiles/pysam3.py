import pysam
samfile = pysam.AlignmentFile("sorted1.bam", "rb")
d={}
for pileupcolumn in samfile.pileup("20", 20000017 , 20000269):
	a=t=g=c=0
	for pileupread in pileupcolumn.pileups:
		if not pileupread.is_del and not pileupread.is_refskip:
			v=pileupread.alignment.query_sequence[pileupread.query_position]
			if v=='A':
				a=a+1  
			elif v=='T':
				t=t+1
			elif v=='G':
				g=g+1
			else:
				c=c+1
	m=max(a,t,g,c)
	d.update({pileupcolumn.pos:m})
	key=[]
	value=[]	
	for k,v1 in d.items():
		key.append(k)
		value.append(v1)

import matplotlib.pyplot as plt
plt.plot(key,value)
plt.show()    
samfile.close()
